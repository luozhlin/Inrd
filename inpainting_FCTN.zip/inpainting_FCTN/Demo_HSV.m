%% =================================================================
% This script runs the FCTN decomposition-based TC method
%
% More detail can be found in [1]
% [1] Yu-Bang Zheng, Ting-Zhu Huang*, Xi-Le Zhao*, Qibin Zhao, Tai-Xiang Jiang
%     Fully-Connected Tensor Network Decomposition and Its Application
%     to Higher-Order Tensor Completion
%
% Please make sure your data is in range [0, 1].
%
% Created by Yu-Bang Zheng (zhengyubang@163.com)
% Jun. 06, 2020
% Updated by Yu-Bang Zheng
% Dec. 06, 2020

%% =================================================================
clc;
clear;
addpath(genpath('lib'));
addpath(genpath('data'));
addpath("assess_fold");
%%
methodname    = {'Observed', 'FCTN-TC'};
Mnum          = length(methodname);
Re_tensor     = cell(Mnum,1);
psnr          = zeros(Mnum,1);
ssim          = zeros(Mnum,1);
time          = zeros(Mnum,1);


filename = 'WHU_inpainting_5.mat';
data_dir = './data';
data_path = fullfile(data_dir, filename);
load(data_path);



%% Sampling with random position
% sample_ratio = 0.05;
% fprintf('=== The sample ratio is %4.2f ===\n', sample_ratio);
T         = gt;
Ndim      = ndims(T);
[M, N, B]     = size(T);
rand('seed',2);
Omega = logical(mask);
% Omega     = find(rand(prod(Nway),1)<sample_ratio);
% F         = zeros(Nway);
% F(Omega)  = T(Omega);
F = input;
%%
% i  = 1;
% Re_tensor{i} = F;
% [psnr(i), ssim(i)] = quality_ybz(T*255, Re_tensor{i}*255);
% enList = 1;

%% Perform  algorithms
i = i+1;
% initialization of the parameters
% Please refer to our paper to set the parameters
opts=[];
opts.max_R = [0,  4,  4;
              0,  0,  4;
              0,  0,  0];  
opts.R     = [0,  2,  2;
              0,  0,  2;
              0,  0,  0];
%     R     = [0,  R_{1,2}, R_{1,3}, ..., R_{1,N};
%              0,     0,    R_{2,3}, ..., R_{2,N};
%              ...
%              0,     0,       0,    ..., R_{N-1,N};
%              0,     0,       0,    ...,   0     ];
opts.tol   = 1e-5;
opts.maxit = 1000;
opts.rho   = 0.1;
%%%%%
% fprintf('\n');
% disp(['performing ',methodname{i}, ' ... ']);
t0= tic;
% Please see the difference between 'inc_FCTN_TC' and 'inc_FCTN_TC_end' in README.txt. 
%[Re_tensor{i},G,Out]        = inc_FCTN_TC(F,Omega,opts);
[result,G,Out]        = inc_FCTN_TC_end(F,logical(mask),opts);

% [psnr(i), ssim(i)]          = quality_ybz(T*255, Re_tensor{i}*255);
% enList = [enList,i];


[NGmeet_PSNR,NGmeet_SSIM,NGmeet_SAM,NGmeet_MQ] = evaluate(gt,result,M,N);
disp(['Method Name:FCTN    ', ', MPSNR=' num2str(mean(NGmeet_PSNR),'%5.2f')  ...
           ',MSSIM = ' num2str(mean(NGmeet_SSIM),'%5.4f')  ',SAM=' num2str(NGmeet_SAM,'%5.2f')...
           ',MQ=' num2str(mean(NGmeet_MQ),'%5.4f')]);



% %% Show result
% fprintf('\n');
% fprintf('================== Result =====================\n');
% fprintf(' %8.8s    %5.4s    %5.4s    \n','method','PSNR', 'SSIM' );
% for i = 1:length(enList)
%     fprintf(' %8.8s    %5.3f    %5.3f    \n',...
%     methodname{enList(i)},psnr(enList(i)), ssim(enList(i)));
% end
% fprintf('================== Result =====================\n');
% figure,
% show_figResult(Re_tensor,T,min(T(:)),max(T(:)),methodname,enList,1,prod(Nway(3:end)))

results_dir = './results';
save_path = fullfile(results_dir, filename);

save(save_path, 'result');
disp(['数据已保存至: ', save_path]);
