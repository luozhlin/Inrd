clear
clc


currentFolder = pwd;
addpath(genpath(currentFolder));
addpath assess_fold;

% Load data
filename = 'KSC_inpainting_7.mat';
data_dir = './data';
data_path = fullfile(data_dir, filename);
load(data_path);


X = input;
[M, N, B] = size(X);
W = double(mask);
% TRLRF
r=5*ones(1,3); % TR-rank 
maxiter=300; % maxiter 300~500
tol=1e-6; % 1e-6~1e-8
Lambda=5; % usually 1~10
ro=1.1; % 1~1.5
K=1e0; % 1e-1~1e0 
[X_hat,~,~]=TRLRF(X,W,r,maxiter,K,ro,Lambda,tol);


[NGmeet_PSNR,NGmeet_SSIM,NGmeet_SAM,NGmeet_MQ] = evaluate(gt,X_hat,M,N);
disp(['Method Name:ETPTV    ', ', MPSNR=' num2str(mean(NGmeet_PSNR),'%5.2f')  ...
           ',MSSIM = ' num2str(mean(NGmeet_SSIM),'%5.4f')  ',SAM=' num2str(NGmeet_SAM,'%5.2f')...
           ',MQ=' num2str(mean(NGmeet_MQ),'%5.4f')]);

results_dir = './results';
save_path = fullfile(results_dir, filename);

result = X_hat;
save(save_path, 'result');
disp(['数据已保存至: ', save_path]);