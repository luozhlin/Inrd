function [X]=tFold(X,S)
X=reshape(X,S);
end